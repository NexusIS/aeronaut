from aeronaut.resource.cloud.account import Account


class MyAccount(Account):
    pass
