Aeronaut: A client library for DiData Cloud
===========================================

It's alpha, it may have bugs, and it's free!

See http://pythonhosted.org//aeronaut/ for usage.

See LICENSE.txt for licensing information.
